# Piano di collaudo

1. Verificare che repository e pipeline siano privati e non contengano segreti.
2. Eseguire analisi Flutter e test widget.
3. Produrre APK debug e build Windows.
4. Integrare il sorgente applicativo effettivo.
5. Configurare autenticazione utente per il progetto Supabase TEST.
6. Verificare accesso autorizzato e rifiuto di accesso non autorizzato.
7. Per ogni scrittura di test, rileggere il record e confrontare il risultato.
8. Provare idempotenza, lock concorrenti, annullamento e recupero errori.
9. Verificare che nessun test punti al progetto di produzione.
10. Registrare esito, log e versione per ciascun test.

**Nessuno di questi test end-to-end è dichiarato superato in base alla sola presenza di questo kit.**
