import 'package:flutter_test/flutter_test.dart';
import 'package:collection_by_valora/main.dart';
import 'package:flutter/material.dart';

void main() {
  testWidgets('Mostra il titolo e l'ambiente TEST', (tester) async {
    await tester.pumpWidget(const CollectionByValoraApp());
    expect(find.text('COLLECTION by VALORA'), findsOneWidget);
    expect(find.text('Ambiente di sviluppo TEST'), findsOneWidget);
  });
}
