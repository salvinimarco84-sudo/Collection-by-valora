import 'package:flutter/material.dart';

void main() {
  runApp(const CollectionByValoraApp());
}

class CollectionByValoraApp extends StatelessWidget {
  const CollectionByValoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'COLLECTION by VALORA',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B1E24)),
        useMaterial3: true,
      ),
      home: const EnvironmentStatusPage(),
    );
  }
}

class EnvironmentStatusPage extends StatelessWidget {
  const EnvironmentStatusPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('COLLECTION by VALORA')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          Icon(Icons.inventory_2_outlined, size: 56),
          SizedBox(height: 16),
          Text(
            'Ambiente di sviluppo TEST',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 12),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Struttura iniziale. Nessuna operazione sul database viene eseguita. '
                'Il codice applicativo completo e il runtime autorizzato devono essere integrati '
                'prima del collaudo funzionale.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
